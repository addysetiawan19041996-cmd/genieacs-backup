// /opt/genieacs/ext/history.js
const now = new Date().toISOString().split("T")[0]; // YYYY-MM-DD
const rx = declare("Device.CustomParameters.rxpower", {value: Date.now()}).value[0] || "N/A";
let history = declare("Device.CustomParameters.redamanHistory", {value: Date.now()}).value[0] || "[]";

history = JSON.parse(history);
history.push({ date: now, value: rx });

// Batasi hanya 30 hari
if (history.length > 30) history.shift();

return { writable: true, value: [JSON.stringify(history), "xsd:string"] };

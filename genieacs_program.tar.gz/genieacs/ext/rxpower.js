// /opt/genieacs/ext/rxpower.js
let m = "N/A";
let db = "";
let zte = declare("InternetGatewayDevice.WANDevice.*.X_ZTE-COM_WANPONInterfaceConfig.RXPower", {value: Date.now()});
let huawei = declare("InternetGatewayDevice.WANDevice.*.X_GponInterafceConfig.RXPower", {value: Date.now()});
let fiberhome = declare("InternetGatewayDevice.WANDevice.*.X_FH_GponInterfaceConfig.RXPower", {value: Date.now()});

if (zte.size) {
   let val = zte.value[0];
   if (val < 0) m = val;
}
else if (huawei.size) {
  m = huawei.value[0];
}
else if (fiberhome.size) {
  m = fiberhome.value[0];
}

return {writable: false, value: [m, "xsd:string"]};

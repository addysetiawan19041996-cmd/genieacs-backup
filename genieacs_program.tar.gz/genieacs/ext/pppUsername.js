// /opt/genieacs/ext/pppUsername.js
const now = Date.now();
let result = '-';

let keys = [
    'InternetGatewayDevice.WANDevice.*.WANConnectionDevice.*.WANPPPConnection.*.Username',
    'Device.PPP.Interface.*.Username',
];

for (let key of keys) {
    let d = declare(key, {path: now, value: now});
    for (let item of d) {
        if (item.value && item.value[0]) {
            result = item.value[0];
        }
    }
}

return {writable: false, value: [result, "xsd:string"]};

export default window.clientConfig;
export const configSnapshot = window.configSnapshot;
export const genieacsVersion = window.genieacsVersion;
